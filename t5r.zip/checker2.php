<?php
// BROK - @x_BRK - @i_BRK //
date_default_timezone_set('Asia/Baghdad');
if (!file_exists('madeline.php')) {
 copy('https://phar.madelineproto.xyz/madeline.php', 'madeline.php');
}
define('MADELINE_BRANCH', 'deprecated');
include 'madeline.php';  
$settings['app_info']['api_id'] = 203088;  
$settings['app_info']['api_hash'] = 'f360233d3627586775bd7298ee775bd1';  
$MadelineProto = new \danog\MadelineProto\API('m2.madeline', $settings);  
$MadelineProto->start(); 
    $brokch = file_get_contents("oldchannel2");
    $type = file_get_contents('type2');
    $x = 0; 
    $admin = file_get_contents('brokadmin');
while(1){
    $users = explode("\n",file_get_contents("users2"));
    foreach($users as $user){
        if($user != ""){
          if($type == 'OldChannel'){
            try{
            	$MadelineProto->messages->getPeerDialogs(['peers' => [$user]]);
                          $x++;
            } catch (\danog\MadelineProto\Exception | \danog\MadelineProto\RPCErrorException $e) {
                    try{
                        $MadelineProto->channels->updateUsername(['channel' => $brokch, 'username' => $user]);
                        $phone = file_get_contents('phone2');
                        $time = date("m/d h:i:s"); 
$MadelineProto->messages->sendMessage(['peer' => "$admin", 'message' => "- Second Checker .
- Request Done .
- New ID => 〔 @$user 〕 .
- Clicks => 〔 $x 〕 .
- Time => 〔 $time 〕 .
- Phone => 〔 $phone 〕 .
- - - - -
- BY => @OO6OOO ."]);
file_put_contents("run2","تم الايقاف");
                        exit;
                    }catch(Exception $e){
$MadelineProto->messages->sendMessage(['peer' => "$admin", 'message' => "- Second Checker .\n- @$user => ".$e->getMessage()
]);
file_put_contents("run2","تم الايقاف");
exit;
                    }
                    }
	        }
        }
    }
if($type == 'Account'){
try{
            	$MadelineProto->messages->getPeerDialogs(['peers' => [$user]]);
                          $x++;
            } catch (\danog\MadelineProto\Exception | \danog\MadelineProto\RPCErrorException $e) {
                    try{
                        $MadelineProto->account->updateUsername(['username' => $user]);
                        $phone = file_get_contents('phone2');
                        $time = date("m/d h:i:s");
$MadelineProto->messages->sendMessage(['peer' => "$admin", 'message' => "- Second Checker .
- Request Done .
- New ID => 〔 @$user 〕 .
- Clicks => 〔 $x 〕 .
- Time => 〔 $time 〕 .
- Phone => 〔 $phone 〕 .
- - - - -
- BY => @OO6OOO ."]);
file_put_contents("run2","تم الايقاف");
                        exit;
                    }catch(Exception $e){
$MadelineProto->messages->sendMessage(['peer' => "$admin", 'message' => "- Second Checker \n- @$user => ".$e->getMessage()
]);
file_put_contents("run2","تم الايقاف");
exit;
                    }
                    }
	        }
        }