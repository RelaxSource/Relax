<?php
// BY BROK- @OO6OOO - @OO6OOO //
require('conf.php');
if (!file_exists("token")) {
$token =  readline("- Enter Token => ");
file_put_contents("token", $token);
if (!file_exists("ID")) {
$id = readline("- Enter iD => ");
file_put_contents("ID", $id);
if (!file_exists("brokadmin")) {
$brokadmin = readline("- Enter Sudo Username => ");
file_put_contents("brokadmin", $brokadmin);
}
}
}
$sudo = file_get_contents('ID');
$token = file_get_contents('token');
define('API_KEY',$token);
function bot($method,$datas=[]){
$url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch));
}else{
return json_decode($res,true);
}
}
$lastupdid = 1; 
while(true){ 
$upd = bot("getUpdates", ["offset" => $lastupdid]); 
if(isset($upd['result'][0])){ 
$text = $upd['result'][0]['message']['text']; 
$chat_id = $upd['result'][0]['message']['chat']['id']; 
$from_id = $upd['result'][0]['message']['from']['id']; 
$message = $upd['result'][0]['message']; 
if($text == '/start' and $chat_id != $sudo){ 
bot('sendmessage',[ 
'chat_id'=>$chat_id,  
'text'=>"- اهلا بك عزيزي هذا التشيكر خاص ب @OO6OOO .
- لشراء نسخة خاصة بك قم بمراسلة المطور .
",'parse_mode' => "MarkDown", 'disable_web_page_preview' => true,
'reply_markup' => json_encode(['inline_keyboard' => [[['text' => "- BROK .'", 'url' => "https://t.me/OO6OOO"]], ]]) ]);
}
if($from_id == $sudo){ 
if($text == '/start' or $text == '- رجوع .'){ 
bot('sendmessage',[ 
'chat_id'=>$chat_id,  
'text'=>"- اهلا بك عزيزي في قائمة اوامر التشيكر .
- قم بأختيار رقم التشيكر من الازرار بلأسفل .
- يمكنك ايضا استخدام الاوامر المشتركة بين جميع التشيكرات .
- - - - -
- BY => @OO6OOO .", 
 'inline_keyboard'=>true,
 'reply_markup'=>json_encode([
      'keyboard'=>[
             [['text'=>'- التشيكر الأول .'],['text'=>'- التشيكر الثاني .']],
             [['text'=>'- التشيكر الثالث .']],
             [['text'=>'- التشيكر الرابع .'],['text'=>'- التشيكر الخامس .']],
             [['text'=>'- عرض معلومات الكل .'],['text'=>'- عرض معرفات الكل .']],
             [['text'=>'- تثبيت بجميع التشيكرات .']],
             [['text'=>'- اضافة لستة للكل .'],['text'=>'- حذف لستات الكل .']],
             [['text'=>'- تشغيل الكل .'],['text'=>'- ايقاف الكل .']],
             [['text'=>'- ارسال فيديو تعليمي .']],
      ]	
		]),'resize_keyboard'=>true
]); 
} 
if($text == '- التشيكر الأول .'){ 
bot('sendmessage',[ 
'chat_id'=>$chat_id,  
'text'=>"- اهلا بك عزيزي في اوامر التشيكر الأول .\n- ملاحظة : الرقم 1 يعني رقم التشيكر .\n- - - - -\n- BY => @OO6OOO .", 
    'inline_keyboard'=>true,
 'reply_markup'=>json_encode([
         'keyboard'=>[
             [['text'=>'- تثبيت 1 .'],['text'=>'- حذف معرف 1 .']],
             [['text'=>'- معلومات التشيكر 1 .'],['text'=>'- لستة المعرفات 1 .']],
             [['text'=>'- تثبيت بقناة قديمة 1 .'],['text'=>'- تثبيت بحساب 1 .']],
             [['text'=>'- اضافة لستة 1 .'],['text'=>'- حذف كل المعرفات 1 .']],
             [['text'=>'- تشغيل التشيكر 1 .'],['text'=>'- ايقاف التشيكر 1 .']],
             [['text'=>'- تسجيل 1 .']],
             [['text'=>'- رجوع .']],
      ]	
		]),'resize_keyboard'=>true
]);
}
if($text == '- التشيكر الثاني .'){ 
bot('sendmessage',[ 
'chat_id'=>$chat_id,  
'text'=>"- اهلا بك عزيزي في اوامر التشيكر الثاني .\n- ملاحظة : الرقم 2 يعني رقم التشيكر .\n- - - - -\n- BY => @OO6OOO .", 
    'inline_keyboard'=>true,
 'reply_markup'=>json_encode([
         'keyboard'=>[
             [['text'=>'- تثبيت 2 .'],['text'=>'- حذف معرف 2 .']],
             [['text'=>'- معلومات التشيكر 2 .'],['text'=>'- لستة المعرفات 2 .']],
             [['text'=>'- تثبيت بقناة قديمة 2 .'],['text'=>'- تثبيت بحساب 2 .']],
             [['text'=>'- اضافة لستة 2 .'],['text'=>'- حذف كل المعرفات 2 .']],
             [['text'=>'- تشغيل التشيكر 2 .'],['text'=>'- ايقاف التشيكر 2 .']],
             [['text'=>'- تسجيل 2 .']],
             [['text'=>'- رجوع .']],
      ]
		])
]); 
}
if($text == '- التشيكر الثالث .'){ 
bot('sendmessage',[ 
'chat_id'=>$chat_id,  
'text'=>"- اهلا بك عزيزي في اوامر التشيكر الثالث .\n- ملاحظة : الرقم 3 يعني رقم التشيكر .\n- - - - -\n- BY => @OO6OOO .", 
    'inline_keyboard'=>true,
 'reply_markup'=>json_encode([
         'keyboard'=>[
             [['text'=>'- تثبيت 3 .'],['text'=>'- حذف معرف 3 .']],
             [['text'=>'- معلومات التشيكر 3 .'],['text'=>'- لستة المعرفات 3 .']],
             [['text'=>'- تثبيت بقناة قديمة 3 .'],['text'=>'- تثبيت بحساب 3 .']],
             [['text'=>'- اضافة لستة 3 .'],['text'=>'- حذف كل المعرفات 3 .']],
             [['text'=>'- تشغيل التشيكر 3 .'],['text'=>'- ايقاف التشيكر 3 .']],
             [['text'=>'- تسجيل 3 .']],
             [['text'=>'- رجوع .']],
      ]
		])
]); 
}
if($text == '- التشيكر الرابع .'){ 
bot('sendmessage',[ 
'chat_id'=>$chat_id,  
'text'=>"- اهلا بك عزيزي في اوامر التشيكر الرابع .\n- ملاحظة : الرقم 4 يعني رقم التشيكر .\n- - - - -\n- BY => @OO6OOO .", 
    'inline_keyboard'=>true,
 'reply_markup'=>json_encode([
         'keyboard'=>[
             [['text'=>'- تثبيت 4 .'],['text'=>'- حذف معرف 4 .']],
             [['text'=>'- معلومات التشيكر 4 .'],['text'=>'- لستة المعرفات 4 .']],
             [['text'=>'- تثبيت بقناة قديمة 4 .'],['text'=>'- تثبيت بحساب 4 .']],
             [['text'=>'- اضافة لستة 4 .'],['text'=>'- حذف كل المعرفات 4 .']],
             [['text'=>'- تشغيل التشيكر 4 .'],['text'=>'- ايقاف التشيكر 4 .']],
             [['text'=>'- تسجيل 4 .']],
             [['text'=>'- رجوع .']],
      ]
		])
]); 
}
if($text == '- التشيكر الخامس .'){ 
bot('sendmessage',[ 
'chat_id'=>$chat_id,  
'text'=>"- اهلا بك عزيزي في اوامر التشيكر الخامس .\n- ملاحظة : الرقم 5 يعني رقم التشيكر .\n- - - - -\n- BY => @OO6OOO .", 
    'inline_keyboard'=>true,
 'reply_markup'=>json_encode([
         'keyboard'=>[
             [['text'=>'- تثبيت 5 .'],['text'=>'- حذف معرف 5 .']],
             [['text'=>'- معلومات التشيكر 5 .'],['text'=>'- لستة المعرفات 5 .']],
             [['text'=>'- تثبيت بقناة قديمة 5 .'],['text'=>'- تثبيت بحساب 5 .']],
             [['text'=>'- اضافة لستة 5 .'],['text'=>'- حذف كل المعرفات 5 .']],
             [['text'=>'- تشغيل التشيكر 5 .'],['text'=>'- ايقاف التشيكر 5 .']],
             [['text'=>'- تسجيل 5 .']],
             [['text'=>'- رجوع .']],
      ]
		])
]); 
}
// Checker 1 start //
if($text == '- تثبيت بقناة قديمة 1 .'){ 
  file_put_contents('type1','OldChannel');
bot('sendmessage',[ 
'chat_id'=>$chat_id,  
'text'=>"- تم وضع التثبيت في قناة قديمة .\n- قم بتعيين القناة القديمة الان مثل الاسفل .
/old1 @OO6OOO", 
]); 
}  
if($text == '- تثبيت بحساب 1 .'){ 
  file_put_contents('type1','Account');
bot('sendmessage',[ 
'chat_id'=>$chat_id,  
'text'=>"- تم وضع التثبيت في حساب .", 
]); 
} 
if($text == '- تثبيت 1 .'){ 
bot('sendmessage',[ 
  'chat_id'=>$chat_id,  
  'text'=>"- حسنا عزيزي ارسل المعرف مثل الاسفل .
/Pin1 @OO6OOO", 
  ]); 
  } 
  if ($text == "- اضافة لستة 1 .") {
bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- حسنا عزيزي ارسل اللستة مثل الاسفل .
/add1 @OO6OOO\nOO6OOO"]);
  }
if(preg_match('/\/add1 .*/', $text)){
$users = explode ("\n",file_get_contents("users1"));
$text = str_replace('/add1 @', '', $text);
if(!in_array($text,$users)){
          bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- تم اضافة اللستة للتشيكر الأول ."]);
          file_put_contents("users1", trim("\n$text",""),FILE_APPEND);
      }
}
if($text == '- حذف معرف 1 .'){ 
bot('sendmessage',[ 
'chat_id'=>$chat_id,  
'text'=>"- حسنا عزيزي ارسل المعرف مثل الاسفل .
/UnPin1 @OO6OOO", 
]); 
} 
if (preg_match("/\/UnPin1 @(.*)/", $text)) {
  $user = explode("@", $text) [1];
  $data = str_replace("\n" . $user, "", file_get_contents("users1"));
    file_put_contents("users1", $data);
    bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- تم حذف => @$user من لستة التشيكر الاول ."]);
  }
  $se = explode("\n", file_get_contents('users1'));
$u = "";
if ($text == "- لستة المعرفات 1 .") {
  for($i=0; $i<count($se); $i++){
$n1 = $i + 1;
$u .= $n1." => 〔 @".$se[$i]." 〕\n";
}
  bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- معرفات التشيكر الأول . \n$u" ]);
}
if ($text == "- حذف كل المعرفات 1 .") {
  file_put_contents("users1", "");
  bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- تم حذف لستة معرفات التشيكر الاول ."]);
}
$BRoKyes = file_get_contents("run1");
$brokold = file_get_contents("oldchannel1");
$type = file_get_contents('type1');
$phone = file_get_contents('phone1');
if($text  == "- معلومات التشيكر 1 ."){ 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"- معلومات التشيكر الاول .
- حالة التشيكر => 〔 $BRoKyes 〕 .
- القناة القديمة => 〔 @$brokold 〕 .
- التثبيت في => 〔 $type 〕 .
- الرقم => 〔 $phone 〕 .
- - - - - -
- BY => @OO6OOO .
", 
]); 
}
if(preg_match('/Pin1 @/', $text )) { 
$ex = explode('/Pin1 @',$text)[1]; 
file_put_contents("users1",$ex); 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"- تم التثبيت على => @$ex في التشيكر الأول .", 
]); 
} 
if(preg_match('/old1 @/', $text )) { 
  $brok = explode('/old1 @',$text)[1]; 
  file_put_contents("oldchannel1",$brok); 
  bot('sendMessage',[ 
  'chat_id'=>$chat_id, 
  'text'=>"- تم وضع => @$brok كقناة قديمة للتشيكر الاول .", 
  ]); 
  } 
if($text == '- تشغيل التشيكر 1 .'){
file_put_contents("run1","قيد التشغيل");
shell_exec('screen -S ac -X kill'); 
shell_exec('screen -dmS ac php checker1.php'); 
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"- تم تشغيل التشيكر الأول .",
]);
}
if($text == '- ايقاف التشيكر 1 .'){
  file_put_contents('run1','تم الايقاف');
      shell_exec('screen -S ac -X kill'); 
    bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"- تم ايقاف التشيكر الاول .",
    ]);
    }
if($text == '- تسجيل 1 .'){
	system('rm -rf m1.madeline');
	system('rm -rf m1.madeline.lock');
file_put_contents("step1","");
if(file_get_contents("step1") == ""){
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"- حسنا عزيزي ارسل الرقم الان مثل الاسفل .
+9647711322717",
]);
file_put_contents("step1","2");
  system('php g1.php');
}
}
// Checker 2 start //
if($text == '- تثبيت بقناة قديمة 2 .'){ 
  file_put_contents('type2','OldChannel');
bot('sendmessage',[ 
'chat_id'=>$chat_id,  
'text'=>"- تم وضع التثبيت في قناة قديمة .\n- قم بتعيين القناة القديمة الان مثل الاسفل .
/old2 @OO6OOO", 
]); 
}  
if($text == '- تثبيت بحساب 2 .'){ 
  file_put_contents('type2','Account');
bot('sendmessage',[ 
'chat_id'=>$chat_id,  
'text'=>"- تم وضع التثبيت في حساب .", 
]); 
} 
if($text == '- تثبيت 2 .'){ 
bot('sendmessage',[ 
  'chat_id'=>$chat_id,  
  'text'=>"- حسنا عزيزي ارسل المعرف مثل الاسفل .
/Pin2 @OO6OOO", 
  ]); 
  } 
  if ($text == "- اضافة لستة 2 .") {
bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- حسنا عزيزي ارسل اللستة مثل الاسفل .
/add2 @OO6OOO\nOO6OOO"]);
  }
if(preg_match('/\/add2 .*/', $text)){
$users = explode ("\n",file_get_contents("users2"));
$text = str_replace('/add2 @', '', $text);
if(!in_array($text,$users)){
          bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- تم اضافة اللستة للتشيكر الثاني ."]);
          file_put_contents("users2", trim("\n$text",""),FILE_APPEND);
      }
}
if($text == '- حذف معرف 2 .'){ 
bot('sendmessage',[ 
'chat_id'=>$chat_id,  
'text'=>"- حسنا عزيزي ارسل المعرف مثل الاسفل .
/UnPin2 @OO6OOO", 
]); 
} 
if (preg_match("/\/UnPin2 @(.*)/", $text)) {
  $user = explode("@", $text) [1];
  $data = str_replace("\n" . $user, "", file_get_contents("users2"));
    file_put_contents("users2", $data);
    bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- تم حذف => @$user من لستة التشيكر الثاني ."]);
  }
  $se = explode("\n", file_get_contents('users2'));
$u = "";
if ($text == "- لستة المعرفات 2 .") {
  for($i=0; $i<count($se); $i++){
$n1 = $i + 1;
$u .= $n1." => 〔 @".$se[$i]." 〕\n";
}
  bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- معرفات التشيكر الثاني . \n$u" ]);
}
if ($text == "- حذف كل المعرفات 2 .") {
  file_put_contents("users2", "");
  bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- تم حذف لستة معرفات التشيكر الثاني ."]);
}
$BRoKyes = file_get_contents("run2");
$brokold = file_get_contents("oldchannel2");
$type = file_get_contents('type2');
$phone = file_get_contents('phone2');
if($text  == "- معلومات التشيكر 2 ."){ 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"- معلومات التشيكر الثاني .
- حالة التشيكر => 〔 $BRoKyes 〕 .
- القناة القديمة => 〔 @$brokold 〕 .
- التثبيت في => 〔 $type 〕 .
- الرقم => 〔 $phone 〕 .
- - - - - -
- BY => @OO6OOO .
", 
]); 
}
if(preg_match('/Pin2 @/', $text )) { 
$ex = explode('/Pin2 @',$text)[1]; 
file_put_contents("users2",$ex); 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"- تم التثبيت على => @$ex في التشيكر الثاني .", 
]); 
} 
if(preg_match('/old2 @/', $text )) { 
  $brok = explode('/old2 @',$text)[1]; 
  file_put_contents("oldchannel2",$brok); 
  bot('sendMessage',[ 
  'chat_id'=>$chat_id, 
  'text'=>"- تم وضع => @$brok كقناة قديمة للتشيكر الثاني .", 
  ]); 
  } 
if($text == '- تشغيل التشيكر 2 .'){
file_put_contents("run2","قيد التشغيل");
shell_exec('screen -S xs -X kill'); 
shell_exec('screen -dmS xs php checker2.php'); 
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"- تم تشغيل التشيكر الثاني .",
]);
}
if($text == '- ايقاف التشيكر 2 .'){
  file_put_contents('run2','تم الايقاف');
      shell_exec('screen -S xs -X kill'); 
    bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"- تم ايقاف التشيكر الثاني .",
    ]);
    }
if($text == '- تسجيل 2 .'){
	system('rm -rf m2.madeline');
	system('rm -rf m2.madeline.lock');
file_put_contents("step2","");
if(file_get_contents("step2") == ""){
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"- حسنا عزيزي ارسل الرقم الان مثل الاسفل .
+9647711322717",
]);
file_put_contents("step2","2");
  system('php g2.php');
}
}
// Checker 3 start //
if($text == '- تثبيت بقناة قديمة 3 .'){ 
  file_put_contents('type3','OldChannel');
bot('sendmessage',[ 
'chat_id'=>$chat_id,  
'text'=>"- تم وضع التثبيت في قناة قديمة .\n- قم بتعيين القناة القديمة الان مثل الاسفل .
/old3 @OO6OOO", 
]); 
}  
if($text == '- تثبيت بحساب 3 .'){ 
  file_put_contents('type3','Account');
bot('sendmessage',[ 
'chat_id'=>$chat_id,  
'text'=>"- تم وضع التثبيت في حساب .", 
]); 
} 
if($text == '- تثبيت 3 .'){ 
bot('sendmessage',[ 
  'chat_id'=>$chat_id,  
  'text'=>"- حسنا عزيزي ارسل المعرف مثل الاسفل .
/Pin3 @OO6OOO", 
  ]); 
  } 
  if ($text == "- اضافة لستة 3 .") {
bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- حسنا عزيزي ارسل اللستة مثل الاسفل .
/add3 @OO6OOO\nOO6OOO"]);
  }
if(preg_match('/\/add3 .*/', $text)){
$users = explode ("\n",file_get_contents("users3"));
$text = str_replace('/add3 @', '', $text);
if(!in_array($text,$users)){
          bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- تم اضافة اللستة للتشيكر الثالث ."]);
          file_put_contents("users3", trim("\n$text",""),FILE_APPEND);
      }
}
if($text == '- حذف معرف 3 .'){ 
bot('sendmessage',[ 
'chat_id'=>$chat_id,  
'text'=>"- حسنا عزيزي ارسل المعرف مثل الاسفل .
/UnPin3 @OO6OOO", 
]); 
} 
if (preg_match("/\/UnPin3 @(.*)/", $text)) {
  $user = explode("@", $text) [1];
  $data = str_replace("\n" . $user, "", file_get_contents("users3"));
    file_put_contents("users3", $data);
    bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- تم حذف => @$user من لستة التشيكر الثالث ."]);
  }
  $se = explode("\n", file_get_contents('users3'));
$u = "";
if ($text == "- لستة المعرفات 3 .") {
  for($i=0; $i<count($se); $i++){
$n1 = $i + 1;
$u .= $n1." => 〔 @".$se[$i]." 〕\n";
}
  bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- معرفات التشيكر الثالث . \n$u" ]);
}
if ($text == "- حذف كل المعرفات 3 .") {
  file_put_contents("users3", "");
  bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- تم حذف لستة معرفات التشيكر الثالث ."]);
}
$BRoKyes = file_get_contents("run3");
$brokold = file_get_contents("oldchannel3");
$type = file_get_contents('type3');
$phone = file_get_contents('phone3');
if($text  == "- معلومات التشيكر 3 ."){ 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"- معلومات التشيكر الثالث .
- حالة التشيكر => 〔 $BRoKyes 〕 .
- القناة القديمة => 〔 @$brokold 〕 .
- التثبيت في => 〔 $type 〕 .
- الرقم => 〔 $phone 〕 .
- - - - - -
- BY => @OO6OOO .
", 
]); 
}
if(preg_match('/Pin3 @/', $text )) { 
$ex = explode('/Pin3 @',$text)[1]; 
file_put_contents("users3",$ex); 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"- تم التثبيت على => @$ex في التشيكر الثالث .", 
]); 
} 
if(preg_match('/old3 @/', $text )) { 
  $brok = explode('/old3 @',$text)[1]; 
  file_put_contents("oldchannel3",$brok); 
  bot('sendMessage',[ 
  'chat_id'=>$chat_id, 
  'text'=>"- تم وضع => @$brok كقناة قديمة للتشيكر الثالث .", 
  ]); 
  } 
if($text == '- تشغيل التشيكر 3 .'){
file_put_contents("run3","قيد التشغيل");
shell_exec('screen -S um -X kill'); 
shell_exec('screen -dmS um php checker3.php'); 
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"- تم تشغيل التشيكر الثالث .",
]);
}
if($text == '- ايقاف التشيكر 3 .'){
  file_put_contents('run3','تم الايقاف');
      shell_exec('screen -S um -X kill'); 
    bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"- تم ايقاف التشيكر الثالث .",
    ]);
    }
if($text == '- تسجيل 3 .'){
	system('rm -rf m3.madeline');
	system('rm -rf m3.madeline.lock');
file_put_contents("step3","");
if(file_get_contents("step3") == ""){
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"- حسنا عزيزي ارسل الرقم الان مثل الاسفل .
+9647711322717",
]);
file_put_contents("step3","2");
  system('php g3.php');
}
}
// Checker 4 start //
if($text == '- تثبيت بقناة قديمة 4 .'){ 
  file_put_contents('type4','OldChannel');
bot('sendmessage',[ 
'chat_id'=>$chat_id,  
'text'=>"- تم وضع التثبيت في قناة قديمة .\n- قم بتعيين القناة القديمة الان مثل الاسفل .
/old4 @OO6OOO", 
]); 
}  
if($text == '- تثبيت بحساب 4 .'){ 
  file_put_contents('type4','Account');
bot('sendmessage',[ 
'chat_id'=>$chat_id,  
'text'=>"- تم وضع التثبيت في حساب .", 
]); 
} 
if($text == '- تثبيت 4 .'){ 
bot('sendmessage',[ 
  'chat_id'=>$chat_id,  
  'text'=>"- حسنا عزيزي ارسل المعرف مثل الاسفل .
/Pin4 @OO6OOO", 
  ]); 
  } 
  if ($text == "- اضافة لستة 4 .") {
bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- حسنا عزيزي ارسل اللستة مثل الاسفل .
/add4 @OO6OOO\nOO6OOO"]);
  }
if(preg_match('/\/add4 .*/', $text)){
$users = explode ("\n",file_get_contents("users4"));
$text = str_replace('/add4 @', '', $text);
if(!in_array($text,$users)){
          bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- تم اضافة اللستة للتشيكر الرابع ."]);
          file_put_contents("users4", trim("\n$text",""),FILE_APPEND);
      }
}
if($text == '- حذف معرف 4 .'){ 
bot('sendmessage',[ 
'chat_id'=>$chat_id,  
'text'=>"- حسنا عزيزي ارسل المعرف مثل الاسفل .
/UnPin4 @OO6OOO", 
]); 
} 
if (preg_match("/\/UnPin4 @(.*)/", $text)) {
  $user = explode("@", $text) [1];
  $data = str_replace("\n" . $user, "", file_get_contents("users4"));
    file_put_contents("users4", $data);
    bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- تم حذف => @$user من لستة التشيكر الرابع ."]);
  }
  $se = explode("\n", file_get_contents('users4'));
$u = "";
if ($text == "- لستة المعرفات 4 .") {
  for($i=0; $i<count($se); $i++){
$n1 = $i + 1;
$u .= $n1." => 〔 @".$se[$i]." 〕\n";
}
  bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- معرفات التشيكر الرابع . \n$u" ]);
}
if ($text == "- حذف كل المعرفات 4 .") {
  file_put_contents("users4", "");
  bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- تم حذف لستة معرفات التشيكر الرابع ."]);
}
$BRoKyes = file_get_contents("run4");
$brokold = file_get_contents("oldchannel4");
$type = file_get_contents('type4');
$phone = file_get_contents('phone4');
if($text  == "- معلومات التشيكر 4 ."){ 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"- معلومات التشيكر الرابع .
- حالة التشيكر => 〔 $BRoKyes 〕 .
- القناة القديمة => 〔 @$brokold 〕 .
- التثبيت في => 〔 $type 〕 .
- الرقم => 〔 $phone 〕 .
- - - - - -
- BY => @OO6OOO .
", 
]); 
}
if(preg_match('/Pin4 @/', $text )) { 
$ex = explode('/Pin4 @',$text)[1]; 
file_put_contents("users4",$ex); 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"- تم التثبيت على => @$ex في التشيكر الرابع .", 
]); 
} 
if(preg_match('/old4 @/', $text )) { 
  $brok = explode('/old4 @',$text)[1]; 
  file_put_contents("oldchannel4",$brok); 
  bot('sendMessage',[ 
  'chat_id'=>$chat_id, 
  'text'=>"- تم وضع => @$brok كقناة قديمة للتشيكر الرابع .", 
  ]); 
  } 
if($text == '- تشغيل التشيكر 4 .'){
file_put_contents("run4","قيد التشغيل");
shell_exec('screen -S br -X kill'); 
shell_exec('screen -dmS br php checker4.php'); 
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"- تم تشغيل التشيكر الرابع .",
]);
}
if($text == '- ايقاف التشيكر 4 .'){
  file_put_contents('run4','تم الايقاف');
      shell_exec('screen -S br -X kill'); 
    bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"- تم ايقاف التشيكر الرابع .",
    ]);
    }
if($text == '- تسجيل 4 .'){
	system('rm -rf m4.madeline');
	system('rm -rf m4.madeline.lock');
file_put_contents("step4","");
if(file_get_contents("step4") == ""){
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"- حسنا عزيزي ارسل الرقم الان مثل الاسفل .
+9647711322717",
]);
file_put_contents("step4","2");
  system('php g4.php');
}
}
// Checker 5 start //
if($text == '- تثبيت بقناة قديمة 5 .'){ 
  file_put_contents('type5','OldChannel');
bot('sendmessage',[ 
'chat_id'=>$chat_id,  
'text'=>"- تم وضع التثبيت في قناة قديمة .\n- قم بتعيين القناة القديمة الان مثل الاسفل .
/old5 @OO6OOO", 
]); 
}  
if($text == '- تثبيت بحساب 5 .'){ 
  file_put_contents('type5','Account');
bot('sendmessage',[ 
'chat_id'=>$chat_id,  
'text'=>"- تم وضع التثبيت في حساب .", 
]); 
} 
if($text == '- تثبيت 5 .'){ 
bot('sendmessage',[ 
  'chat_id'=>$chat_id,  
  'text'=>"- حسنا عزيزي ارسل المعرف مثل الاسفل .
/Pin5 @OO6OOO", 
  ]); 
  } 
  if ($text == "- اضافة لستة 5 .") {
bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- حسنا عزيزي ارسل اللستة مثل الاسفل .
/add5 @OO6OOO\nOO6OOO"]);
  }
if(preg_match('/\/add5 .*/', $text)){
$users = explode ("\n",file_get_contents("users5"));
$text = str_replace('/add5 @', '', $text);
if(!in_array($text,$users)){
          bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- تم اضافة اللستة للتشيكر الخامس ."]);
          file_put_contents("users5", trim("\n$text",""),FILE_APPEND);
      }
}
if($text == '- حذف معرف 5 .'){ 
bot('sendmessage',[ 
'chat_id'=>$chat_id,  
'text'=>"- حسنا عزيزي ارسل المعرف مثل الاسفل .
/UnPin5 @OO6OOO", 
]); 
} 
if (preg_match("/\/UnPin5 @(.*)/", $text)) {
  $user = explode("@", $text) [1];
  $data = str_replace("\n" . $user, "", file_get_contents("users5"));
    file_put_contents("users5", $data);
    bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- تم حذف => @$user من لستة التشيكر الخامس ."]);
  }
  $se = explode("\n", file_get_contents('users5'));
$u = "";
if ($text == "- لستة المعرفات 5 .") {
  for($i=0; $i<count($se); $i++){
$n1 = $i + 1;
$u .= $n1." => 〔 @".$se[$i]." 〕\n";
}
  bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- معرفات التشيكر الخامس . \n$u" ]);
}
if ($text == "- حذف كل المعرفات 5 .") {
  file_put_contents("users5", "");
  bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- تم حذف لستة معرفات التشيكر الخامس ."]);
}
$BRoKyes = file_get_contents("run5");
$brokold = file_get_contents("oldchannel5");
$type = file_get_contents('type5');
$phone = file_get_contents('phone5');
if($text  == "- معلومات التشيكر 5 ."){ 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"- معلومات التشيكر الخامس .
- حالة التشيكر => 〔 $BRoKyes 〕 .
- القناة القديمة => 〔 @$brokold 〕 .
- التثبيت في => 〔 $type 〕 .
- الرقم => 〔 $phone 〕 .
- - - - - -
- BY => @OO6OOO .
", 
]); 
}
if(preg_match('/Pin5 @/', $text )) { 
$ex = explode('/Pin5 @',$text)[1]; 
file_put_contents("users5",$ex); 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"- تم التثبيت على => @$ex في التشيكر الخامس .", 
]); 
} 
if(preg_match('/old5 @/', $text )) { 
  $brok = explode('/old5 @',$text)[1]; 
  file_put_contents("oldchannel5",$brok); 
  bot('sendMessage',[ 
  'chat_id'=>$chat_id, 
  'text'=>"- تم وضع => @$brok كقناة قديمة للتشيكر الخامس .", 
  ]); 
  } 
if($text == '- تشغيل التشيكر 5 .'){
file_put_contents("run5","قيد التشغيل");
shell_exec('screen -S sj -X kill'); 
shell_exec('screen -dmS sj php checker5.php'); 
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"- تم تشغيل التشيكر الخامس .",
]);
}
if($text == '- ايقاف التشيكر 5 .'){
  file_put_contents('run5','تم الايقاف');
      shell_exec('screen -S sj -X kill'); 
    bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"- تم ايقاف التشيكر الخامس .",
    ]);
    }
if($text == '- تسجيل 5 .'){
	system('rm -rf m5.madeline');
	system('rm -rf m5.madeline.lock');
file_put_contents("step5","");
if(file_get_contents("step5") == ""){
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"- حسنا عزيزي ارسل الرقم الان مثل الاسفل .
+9647711322717",
]);
file_put_contents("step5","2");
  system('php g5.php');
}
}
// All Checkers Commands //
$bro1k = file_get_contents('run1');
$bro2k = file_get_contents('run2');
$bro3k = file_get_contents('run3');
$bro4k = file_get_contents('run4');
$bro5k = file_get_contents('run5');
$pho1 = file_get_contents('phone1');
$pho2 = file_get_contents('phone2');
$pho3 = file_get_contents('phone3');
$pho4 = file_get_contents('phone4');
$pho5 = file_get_contents('phone5');
$ol1d = file_get_contents('oldchannel1');
$ol2d = file_get_contents('oldchannel2');
$ol3d = file_get_contents('oldchannel3');
$ol4d = file_get_contents('oldchannel4');
$ol5d = file_get_contents('oldchannel5');
$type1 = file_get_contents('type1');
$type2 = file_get_contents('type2');
$type3 = file_get_contents('type3');
$type4 = file_get_contents('type4');
$type5 = file_get_contents('type5');
if($text == '- عرض معلومات الكل .'){
  bot('sendMessage',[
    'chat_id'=>$chat_id,
    'text'=>"- معلومات جميع التشيكرات .
- - - - -
- التشيكر الاول => 〔 $bro1k 〕 .
- التشيكر الثاني => 〔 $bro2k 〕 .
- التشيكر الثالث => 〔 $bro3k 〕 .
- التشيكر الرابع => 〔 $bro4k 〕 .
- التشيكر الخامس => 〔 $bro5k 〕 .
- - - - - -
- رقم التشيكر الاول => 〔 $pho1 〕 .
- رقم التشيكر الثاني => 〔 $pho2 〕 .
- رقم التشيكر الثالث => 〔 $pho3 〕 .
- رقم التشيكر الرابع => 〔 $pho4 〕 .
- رقم التشيكر الخامس => 〔 $pho5 〕 .
- - - - - -
- القناة القديمة الاولى => 〔 @$ol1d 〕 .
- القناة القديمة الثانية => 〔 @$ol2d 〕 .
- القناة القديمة الثالثة => 〔 @$ol3d 〕 .
- القناة القديمة الرابعة => 〔 @$ol4d 〕 .
- القناة القديمة الخامسة => 〔 @$ol5d 〕 .
- - - - - -
- التثبيت في التشيكر الاول => 〔 $type1 〕 .
- التثبيت في التشيكر الثاني => 〔 $type2 〕 .
- التثبيت في التشيكر الثالث => 〔 $type3 〕 .
- التثبيت في التشيكر الرابع => 〔 $type4 〕 .
- التثبيت في التشيكر الخامس => 〔 $type5 〕 .
- - - - - -
- BY => @OO6OOO ."
  ]);
}
$se1 = explode("\n", file_get_contents('users1'));
$u1 = "";
  $se2 = explode("\n", file_get_contents('users2'));
$u2 = "";
  $se3 = explode("\n", file_get_contents('users3'));
$u3 = "";
  $se4 = explode("\n", file_get_contents('users4'));
$u4 = "";
  $se5 = explode("\n", file_get_contents('users5'));
$u5 = "";
if ($text == "- عرض معرفات الكل .") {
  for($i=0; $i<count($se1); $i++){
$n1 = $i + 1;
$u1 .= $n1." => 〔 @".$se1[$i]."〕\n";
}
  for($i=0; $i<count($se2); $i++){
$n1 = $i + 1;
$u2 .= $n1." => 〔 @".$se2[$i]."〕\n";
}
  for($i=0; $i<count($se3); $i++){
$n1 = $i + 1;
$u3 .= $n1." => 〔 @".$se3[$i]."〕\n";
}
  for($i=0; $i<count($se4); $i++){
$n1 = $i + 1;
$u4 .= $n1." => 〔 @".$se4[$i]."〕\n";
}
  for($i=0; $i<count($se5); $i++){
$n1 = $i + 1;
$u5 .= $n1." => 〔 @".$se5[$i]."〕\n";
}
bot('sendMessage',[
  'chat_id'=>$chat_id,
  'text'=>"- معرفات التشيكر الاول .
$u1 
- - - - - -
- معرفات التشيكر الثاني .
$u2 
- - - - - -
- معرفات التشيكر الثالث .
$u3 
- - - - - -
- معرفات التشيكر الرابع .
$u4
- - - - - -
- معرفات التشيكر الخامس .
$u5
- - - - - -
- BY => @OO6OOO ."
]);
}
if($text == '- تثبيت بجميع التشيكرات .'){
  bot('sendMessage',[
    'chat_id'=>$chat_id,
    'text'=>"- حسنا عزيزي قم بأرسال المعرف مثل الاسفل .
/Pinall @OO6OOO"
  ]);
}
if($text == '- اضافة لستة للكل .'){
  bot('sendMessage',[
    'chat_id'=>$chat_id,
    'text'=>"- حسنا عزيزي قم بأرسال اللستة مثل الاسفل .
/addall @OO6OOO
OO6OOO"
  ]);
}
if($text == '- حذف لستات الكل .'){
  bot('sendMessage',[
    'chat_id'=>$chat_id,
    'text'=>"- تم حذف جميع لستات التشيكرات ."
  ]);
  file_put_contents('users1','');
  file_put_contents('users2','');
  file_put_contents('users3','');
  file_put_contents('users4','');
  file_put_contents('users5','');
}
if($text == '- ايقاف الكل .'){
  bot('sendMessage',[
    'chat_id'=>$chat_id,
    'text'=>"- تم ايقاف كل التشيكرات ."
  ]);
  file_put_contents('run1','تم الايقاف');
  file_put_contents('run2','تم الايقاف');
  file_put_contents('run3','تم الايقاف');
  file_put_contents('run4','تم الايقاف');
  file_put_contents('run5','تم الايقاف');
  shell_exec('screen -S ac -X kill'); 
  shell_exec('screen -S xs -X kill'); 
  shell_exec('screen -S um -X kill'); 
  shell_exec('screen -S br -X kill'); 
  shell_exec('screen -S sj -X kill'); 
}
if($text == '- تشغيل الكل .'){
  bot('sendMessage',[
    'chat_id'=>$chat_id,
    'text'=>"- تم تشغيل جميع التشيكرات ."
  ]);
  file_put_contents('run1','قيد التشغيل');
  file_put_contents('run2','قيد التشغيل');
  file_put_contents('run3','قيد التشغيل');
  file_put_contents('run4','قيد التشغيل');
  file_put_contents('run5','قيد التشغيل');
  shell_exec('screen -S ac -X kill'); 
  shell_exec('screen -dmS ac php checker1.php');
  shell_exec('screen -S xs -X kill'); 
  shell_exec('screen -dmS xs php checker2.php');
  shell_exec('screen -S um -X kill'); 
  shell_exec('screen -dmS um php checker3.php');
  shell_exec('screen -S br -X kill'); 
  shell_exec('screen -dmS br php checker4.php');
  shell_exec('screen -S sj -X kill'); 
  shell_exec('screen -dmS sj php checker5.php');
}
if(preg_match('/Pinall @/', $text )) { 
$ex = explode('/Pinall @',$text)[1]; 
file_put_contents("users1",$ex); 
file_put_contents("users2",$ex); 
file_put_contents("users3",$ex); 
file_put_contents("users4",$ex); 
file_put_contents("users5",$ex); 
bot('sendMessage',[ 
'chat_id'=>$chat_id, 
'text'=>"- تم التثبيت على => @$ex بجميع التشيكرات .", 
]); 
} 
if(preg_match('/\/addall .*/', $text)){
$users1 = explode ("\n",file_get_contents("users1"));
$users2 = explode ("\n",file_get_contents("users2"));
$users3 = explode ("\n",file_get_contents("users3"));
$users4 = explode ("\n",file_get_contents("users4"));
$users5 = explode ("\n",file_get_contents("users5"));
$text = str_replace('/addall @', '', $text);
          bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- تم اضافة اللستة الى جميع التشيكرات ."]);
          file_put_contents("users1", trim("\n$text",""),FILE_APPEND);
          file_put_contents("users2", trim("\n$text",""),FILE_APPEND);
          file_put_contents("users3", trim("\n$text",""),FILE_APPEND);
          file_put_contents("users4", trim("\n$text",""),FILE_APPEND);
          file_put_contents("users5", trim("\n$text",""),FILE_APPEND);
      }
if($text == '- ارسال فيديو تعليمي .'){
  bot('sendvideo',[
    'chat_id'=>$chat_id,
    'video'=>"https://t.me/x_BMC/3",
    'caption'=>"- هذا هو الفيديو التعليمي .\n- اذا واجهت مشاكل قم بمراسلة => @OO6OOO .",
  ]);
      }
} 
$lastupdid = $upd['result'][0]['update_id'] + 1; 
} 
}